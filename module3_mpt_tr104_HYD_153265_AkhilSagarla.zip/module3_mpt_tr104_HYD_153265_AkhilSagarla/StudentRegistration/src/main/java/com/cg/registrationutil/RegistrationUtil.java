package com.cg.registrationutil;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class RegistrationUtil {
	

	WebDriver driver;
	public WebDriver initiateDriver(String name) {
		
		if("chrome".equals(name)){
			System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
			 driver= (WebDriver) new ChromeDriver();
		  // return  driver;
		}
		else if ("firefox".equals(name)){
			System.setProperty("webdriver.firefox.driver", "Drivers\\firefoxdriver.exe");
			 driver= (WebDriver) new FirefoxDriver();
		//	   return  driver;
			
		}
		return driver;

}
	public void closeDriver(WebDriver driver) {
		driver.quit();
		
	}


}

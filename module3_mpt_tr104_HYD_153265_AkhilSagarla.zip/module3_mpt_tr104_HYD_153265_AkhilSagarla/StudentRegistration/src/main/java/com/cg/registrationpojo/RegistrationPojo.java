package com.cg.registrationpojo;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPojo {
	

	@FindBy(how=How.ID, id="txtFirstName")
	private WebElement firstName;
	
	@FindBy(how=How.ID, id="txtLastName")
	private WebElement lastName;

	@FindBy(how=How.ID, id="txtEmail")
	private WebElement email;

	@FindBy(how=How.ID, id="txtPhone")
	private WebElement contactNo;
	

	@FindBy(how=How.ID, id="txtAddress1")
	private WebElement addressline1;
	
	@FindBy(how=How.ID, id="txtAddress2")
	private WebElement addressline2;
	
	@FindBy(how=How.NAME, name="city")
	private WebElement city;
	
	@FindBy(how=How.NAME, name="state")
	private WebElement state;
	
	@FindBy(how=How.LINK_TEXT, linkText="Next")
	private WebElement next;
	

	@FindBy(how=How.NAME, name="graduation")
	private WebElement graduation;
	
	@FindBy(how=How.ID, id="txtPercentage")
	private WebElement percentage;
	
	@FindBy(how=How.ID, id="txtPassYear")
	private WebElement passingYear;
	
	@FindBy(how=How.ID, id="txtProjectName")
	private WebElement projectName;
	
	@FindBy(how=How.ID, id="cbTechnologies")
	private List<WebElement> technologiesUsed;
	
	@FindBy(how=How.ID, id="txtOtherTechs")
	private WebElement otherTechnologies;
	
	@FindBy(how=How.ID, id="btnRegister")
	private WebElement registerMe;
	
	public void clicknext() {
		next.click();
	}
	
	public void ClickRegisterMe() {
		registerMe.click();
	}
	
	
	
	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.clear();
		this.email.sendKeys(email);
	}

	public String getContactNo() {
		return contactNo.getAttribute("value");
	}

	public void setContactNo(String contactNo) {
		this.contactNo.clear();
		this.contactNo.sendKeys(contactNo);
	}

	public String getAddressline1() {
		return addressline1.getAttribute("value");
	}

	public void setAddressline1(String addressline1) {
		this.addressline1.sendKeys(addressline1);
	}

	public String getAddressline2() {
		return addressline2.getAttribute("value");
	}

	public void setAddressline2(String addressline2) {
		this.addressline2.sendKeys(addressline2);
	}

	public String getCity() {
		//return city.getAttribute("value");
		return new Select(this.city).getFirstSelectedOption().getText();
	}

	public void setCity(String city) {
		Select select=new Select(this.city);
		select.selectByVisibleText(city);
		
	//	this.city = city;
	}

	public String getState() {
		return new Select(this.state).getFirstSelectedOption().getText();
	}

	public void setState(String state) {
		Select select=new Select(this.state);
		select.selectByVisibleText(state);
		//this.state = state;
	}
//
//	public WebElement getNext() {
//		return next;
//	}
//
//	public void setNext(WebElement next) {
//		this.next = next;
//	}

	public String getGraduation() {
		//return graduation..getAttribute("value");
		return new Select(this.graduation).getFirstSelectedOption().getText();
	}

	public void setGraduation(String graduation) {
		Select select=new Select(this.graduation);
		select.selectByVisibleText(graduation);
		//this.graduation = graduation;
	}

	public String getPercentage() {
		return percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public String getPassingYear() {
		return passingYear.getAttribute("value");
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public String getProjectName() {
		return projectName.getAttribute("value");
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public String getTechnologiesUsed() {
		
		
			
			for (WebElement webelement : technologiesUsed) {
				if(webelement.isSelected()) {
					return webelement.getAttribute("value");
				}
				
			}
		//return technologiesUsed.getAttribute("value");
		return null;
	}

	public void setTechnologiesUsed(String technologiesUsed) {
	
		if(technologiesUsed.equals(".Net"))
			this.technologiesUsed.get(0).click();
		else if (technologiesUsed.equals("Java")) {
			this.technologiesUsed.get(1).click();
		}
		else if (technologiesUsed.equals("PHP")) {
			this.technologiesUsed.get(2).click();
		}
		else if (technologiesUsed.equals("Other")) {
			this.technologiesUsed.get(3).click();
		}
		
	}

	public String getOtherTechnologies() {
		return otherTechnologies.getAttribute("value");
	}

	public void setOtherTechnologies(String otherTechnologies) {
		this.otherTechnologies.sendKeys(otherTechnologies);
	}

//	public WebElement getRegisterMe() {
//		return registerMe;
//	}
//
//	public void setRegisterMe(WebElement registerMe) {
//		this.registerMe = registerMe;
//	}

	

}

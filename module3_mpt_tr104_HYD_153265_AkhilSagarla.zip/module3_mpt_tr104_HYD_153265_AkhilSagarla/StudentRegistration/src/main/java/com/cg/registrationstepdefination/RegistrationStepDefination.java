package com.cg.registrationstepdefination;

import static org.junit.Assert.assertEquals;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.cg.registrationpojo.RegistrationPojo;
import com.cg.registrationutil.RegistrationUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefination {
	
	
	private Logger log=Logger.getLogger(RegistrationStepDefination.class);
	 private RegistrationPojo pojo = new RegistrationPojo();
	private RegistrationUtil util = new RegistrationUtil();
	WebDriver driver;

	@Before
	public void Initialization() throws Throwable {
		driver = util.initiateDriver("chrome");
		PageFactory.initElements(driver, pojo);
		driver.manage().window().maximize();
		
		
	}

	@After
	public void quit() throws Throwable {
		Thread.sleep(500);
		util.closeDriver(driver);
	}

	@Test
	public void test() throws Throwable {
	
		 i_want_to_fill_the_given_registration_form_successfully();
		 i_click_on_next_link_without_entering_FirstName();
		 it_should_show_alert_message_as_Please_fill_the_First_Name();
		 i_click_on_next_link_without_entering_Last_Name();
		 it_should_show_alert_message_as_Please_fill_the_Last_Name();
		 i_click_on_next_link_without_entering_Email();
		 it_should_show_alert_message_as_Please_fill_the_Email();
		 i_click_on_next_link_without_entering_Valid_Email();
		 it_should_show_alert_message_as_Please_enter_valid_Email_Id();
		 i_click_on_next_link_without_entering_Contactno();
		 it_should_show_alert_message_as_Please_fill_the_Contact_No(); 
		 i_click_on_next_link_without_entering_Valid_Contactno();
		 it_should_show_alert_message_as_Please_enter_valid_Contact_no();
		 i_click_on_next_link_without_entering_AddressLineOne();
		 it_should_show_alert_message_as_Please_fill_AddressLineOne();
		 i_click_on_next_link_without_entering_Addresstwo();
		 it_should_show_alert_message_as_Please_fill_the_Addresstwo();
		 i_click_on_next_link_without_selecting_City();
		 it_should_show_alert_message_as_Please_select_city();
		 i_click_on_next_link_without_selecting_State();
		 it_should_show_alert_message_as_Please_select_State();
		 i_fill_all_the_details_with_valid_information_and_click_on_next();
		 it_should_login_show_personal_deatils_are_validated_and_accepted_successfully_message();
		 
		 i_click_on_RegisterMe_link_without_selecting_graduation();
		 it_should_show_alert_message_as_Please_select_Graduation();
		 i_click_on_RegisterMe_link_without_entering_percentage();
		 it_should_show_alert_message_as_Please_fill_percentage_details();
		 i_click_on_RegisterMe_link_without_entering_passing_year();
		 it_should_show_alert_message_as_Please_fill_passing_year();
		 i_click_on_RegisterMe_link_without_entering_projectname();
		 it_should_show_alert_message_as_Please_fill_project_name();
		 i_click_on_RegisterMe_link_without_selecting_technologies();
		 it_should_show_alert_message_as_Please_select_Technologies_used();
		 i_click_on_RegisterMe_link_without_entering_others_field_by_clicking_on_other_checkbox();
		  it_should_show_alert_message_as_Please_fill_other_technologies_used();
		 i_fill_all_the_details_with_valid_information_and_click_on_registerme();
		 it_should_show_Your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link_message(); 
		 
	}
			 
	@Given("^I want to fill the given registration form successfully$")
	public void i_want_to_fill_the_given_registration_form_successfully() throws Throwable {
		driver.get("D:\\Akhil_Module3\\StudentRegistration\\Web\\PersonalDetails.html");
		
		String actualMesage=driver.getTitle(); // it starts filling the form only if page title matches 
		String expectedMessage="Personal Details";
		Assert.assertEquals(expectedMessage, actualMesage);
	}

	@When("^I click on 'next' link without entering FirstName\\.$")
	public void i_click_on_next_link_without_entering_FirstName() throws Throwable {
		pojo.clicknext();
		Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please fill the First Name'$")
	public void it_should_show_alert_message_as_Please_fill_the_First_Name() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not filling firstname
		String expectedMessage="Please fill the First Name";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please fill the firstName message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setFirstName("Akhil");
	}

	@When("^I click on 'next' link without entering Last Name\\.$")
	public void i_click_on_next_link_without_entering_Last_Name() throws Throwable {
		pojo.clicknext();
		Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please fill the Last Name'$")
	public void it_should_show_alert_message_as_Please_fill_the_Last_Name() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not filling lastname
		String expectedMessage="Please fill the Last Name"; 
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please fill the LastName message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setLastName("Sagarla");
	}

	@When("^I click on 'next' link without entering Email\\.$")
	public void i_click_on_next_link_without_entering_Email() throws Throwable {
		pojo.clicknext();
		Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please fill the Email'$")
	public void it_should_show_alert_message_as_Please_fill_the_Email() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not filling email id
		String expectedMessage="Please fill the Email";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please fill the Email message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setEmail("akhil");
	}

	@When("^I click on 'next' link without entering Valid Email\\.$")
	public void i_click_on_next_link_without_entering_Valid_Email() throws Throwable {
		pojo.clicknext();
		Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please enter valid Email Id'$")
	public void it_should_show_alert_message_as_Please_enter_valid_Email_Id() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for invalid email
		String expectedMessage="Please enter valid Email Id.";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please fill the validEmail message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setEmail("akhil@gmail.com");
	}

	@When("^I click on 'next' link without entering Contactno\\.$")
	public void i_click_on_next_link_without_entering_Contactno() throws Throwable {
		
		//pojo.clicknext();
		//Thread.sleep(500);
		
	}

	@Then("^It should show alert message as 'Please fill the Contact No'$")
	public void it_should_show_alert_message_as_Please_fill_the_Contact_No() throws Throwable {
		
		pojo.clicknext();
		Thread.sleep(500);
	
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not filling contact no
		String expectedMessage="Please fill the Contact No.";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please fill the contactNo message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setContactNo("99516107");
	}

	@When("^I click on 'next' link without entering Valid Contactno\\.$")
	public void i_click_on_next_link_without_entering_Valid_Contactno() throws Throwable {
		pojo.clicknext();
		Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please enter valid Contact no'$")
	public void it_should_show_alert_message_as_Please_enter_valid_Contact_no() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for invalid contact no
		String expectedMessage="Please enter valid Contact no.";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please fill the Correct ContactNo message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setContactNo("9951610704");
	}

	@When("^I click on 'next' link without entering AddressLineOne\\.$")
	public void i_click_on_next_link_without_entering_AddressLineOne() throws Throwable {
		pojo.clicknext();
		Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please fill AddressLineOne'$")
	public void it_should_show_alert_message_as_Please_fill_AddressLineOne() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not filling address1
		String expectedMessage="Please fill the address line 1";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please fill the Address1 message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setAddressline1("Shivanagar,f.no:514");
	}

	@When("^I click on 'next' link without entering Addresstwo\\.$")
	public void i_click_on_next_link_without_entering_Addresstwo() throws Throwable {
		pojo.clicknext();
		Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please fill the Addresstwo'$")
	public void it_should_show_alert_message_as_Please_fill_the_Addresstwo() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not filling Address2
		String expectedMessage="Please fill the address line 2";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please fill the Address2 message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setAddressline2("Hyderabad");
	}

	@When("^I click on 'next' link without selecting City\\.$")
	public void i_click_on_next_link_without_selecting_City() throws Throwable {
		pojo.clicknext();
		Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please select city'$")
	public void it_should_show_alert_message_as_Please_select_city() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not selecting city
		String expectedMessage="Please select city";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please select city- message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setCity("Hyderabad");
	}

	@When("^I click on 'next' link without selecting State\\.$")
	public void i_click_on_next_link_without_selecting_State() throws Throwable {
		pojo.clicknext();
		Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please select State'$")
	public void it_should_show_alert_message_as_Please_select_State() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not selecting state
		String expectedMessage="Please select state";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please select state- message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setState("Telangana");
	}

	@When("^I fill all the details with valid information and click on next\\.$")
	public void i_fill_all_the_details_with_valid_information_and_click_on_next() throws Throwable {
		pojo.clicknext();
		Thread.sleep(500);
	}

	@Then("^It should login show'personal deatils are validated and accepted successfully' message\\.$")
	public void it_should_login_show_personal_deatils_are_validated_and_accepted_successfully_message() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for suucessful filling of all details
		String expectedMessage="Personal details are validated and accepted successfully.";
		Assert.assertEquals(expectedMessage, actualMesage);
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		
		String actualMesage1=driver.getTitle(); //  it starts filling the form only if page title matches 
		String expectedMessage1="Educational Details";
		Assert.assertEquals(expectedMessage, actualMesage);
	}

	@When("^I click on 'RegisterMe' link without selecting graduation\\.$")
	public void i_click_on_RegisterMe_link_without_selecting_graduation() throws Throwable {
	   pojo.ClickRegisterMe();
	   Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please select Graduation'$")
	public void it_should_show_alert_message_as_Please_select_Graduation() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not filling graduation
		String expectedMessage="Please Select Graduation";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please select thegraduation message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setGraduation("BTech");
	}

	@When("^I click on 'RegisterMe' link without entering percentage\\.$")
	public void i_click_on_RegisterMe_link_without_entering_percentage() throws Throwable {
		 pojo.ClickRegisterMe();
		   Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please fill percentage details'$")
	public void it_should_show_alert_message_as_Please_fill_percentage_details() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not filling percentage
		String expectedMessage="Please fill Percentage detail";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please fill the percentage message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setPercentage("75");
	}

	@When("^I click on 'RegisterMe' link without entering passing year \\.$")
	public void i_click_on_RegisterMe_link_without_entering_passing_year() throws Throwable {
		 pojo.ClickRegisterMe();
		   Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please fill passing year'$")
	public void it_should_show_alert_message_as_Please_fill_passing_year() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not filling passing year
		String expectedMessage="Please fill Passing Year";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please fill the passing year message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setPassingYear("2017");
	}

	@When("^I click on 'RegisterMe' link without entering projectname\\.$")
	public void i_click_on_RegisterMe_link_without_entering_projectname() throws Throwable {
		 pojo.ClickRegisterMe();
		   Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please fill project name'$")
	public void it_should_show_alert_message_as_Please_fill_project_name() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not filling project name
		String expectedMessage="Please fill Project Name";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please fill the project name message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setProjectName("Electrical machines");
	}

	@When("^I click on 'RegisterMe' link without selecting technologies\\.$")
	public void i_click_on_RegisterMe_link_without_selecting_technologies() throws Throwable {
		 pojo.ClickRegisterMe();
		   Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please select Technologies used'$")
	public void it_should_show_alert_message_as_Please_select_Technologies_used() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not filling technologies
		String expectedMessage="Please Select Technologies Used";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please fill the technologies message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setTechnologiesUsed("PHP");
		pojo.setTechnologiesUsed("Other");
		//Select select=new Select(null);
		//select.selectByValue("Other");
	}

	@When("^I click on 'RegisterMe' link without entering others field by clicking on other checkbox\\.$")
	public void i_click_on_RegisterMe_link_without_entering_others_field_by_clicking_on_other_checkbox() throws Throwable {
		 pojo.ClickRegisterMe();
		   Thread.sleep(500);
	}

	@Then("^It should show alert message as 'Please fill other technologies used'$")
	public void it_should_show_alert_message_as_Please_fill_other_technologies_used() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not filling other technologies
		String expectedMessage="Please fill other Technologies Used";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("please fill the other technologies message should be displayed");
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		pojo.setOtherTechnologies("Selenium");
	}

	@When("^I fill all the details with valid information and click on registerme\\.$")
	public void i_fill_all_the_details_with_valid_information_and_click_on_registerme() throws Throwable {
		 pojo.ClickRegisterMe();
		   Thread.sleep(500);
	}

	@Then("^It should show 'Your Registration Has succesfully done Plz check you registerd email for account activation link' message\\.$")
	public void it_should_show_Your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link_message() throws Throwable {
		String actualMesage=driver.switchTo().alert().getText(); // takes the alert text for not filling other technologies
		String expectedMessage="Your Registration Has succesfully done Plz check you registerd email for account activation link !!!";
		Assert.assertEquals(expectedMessage, actualMesage);
		log.info("Your Registration Has succesfully done Plz check you registerd email for account activation link !!!");
		driver.switchTo().alert().dismiss();
		//Assert.assertTrue(true);
		log.info("Registration has successfully completed");
	}


		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		
		
	
	


	

}

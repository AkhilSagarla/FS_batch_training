package com.cg.paymentwallet.exception;

public class PaymentWalletException extends Exception{
public PaymentWalletException()
{
	super();
}
public PaymentWalletException(String msg)
{
	super(msg);
}
}

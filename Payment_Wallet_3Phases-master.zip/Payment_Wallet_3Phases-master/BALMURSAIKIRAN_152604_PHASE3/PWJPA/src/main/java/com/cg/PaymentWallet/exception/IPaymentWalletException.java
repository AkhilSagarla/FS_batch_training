package com.cg.PaymentWallet.exception;

public interface IPaymentWalletException {

	char[] MESSAGE1 = null;

}

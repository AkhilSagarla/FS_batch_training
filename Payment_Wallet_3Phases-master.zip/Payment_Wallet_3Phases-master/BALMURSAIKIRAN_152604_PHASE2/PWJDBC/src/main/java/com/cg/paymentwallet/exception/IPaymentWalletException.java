package com.cg.paymentwallet.exception;

public interface IPaymentWalletException {

	char[] MESSAGE1 = null;

}
